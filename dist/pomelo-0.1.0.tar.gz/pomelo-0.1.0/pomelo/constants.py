APP_NAME = "pomelo"

CONFIG_FILE_NAME = "pomelo_config.toml"

TOKEN_KEY = "X-Plex-Token"
DEVICE_NAME_KEY = "X-Plex-Device-Name"
URI_KEY = "uri"

PLUGIN_NAMESPACE = "pomelo.plugins"
